 🎯 PDV Posto de Combustível - Projeto Completo

Sistema completo de Ponto de Venda (PDV) para posto de combustível desenvolvido em Java com Spring Boot (Backend) e Java Swing (Frontend).

## 🎨 Características do Design

Interface moderna com paleta de cores:
- **Preto** (#1E1E1E) - Elementos principais
- **Branco** (#FAFAFA) - Background
- **Vermelho** (#DC143C) - Destaques e ações

## 📋 Pré-requisitos

Antes de começar, certifique-se de ter instalado:

- ☕ **Java JDK 17** ou superior - [Download](https://www.oracle.com/java/technologies/downloads/)
- 📦 **Maven 3.6** ou superior - [Download](https://maven.apache.org/download.cgi)
- 🐘 **PostgreSQL 12** ou superior - [Download](https://www.postgresql.org/download/)
- 🔧 **Git** (opcional) - [Download](https://git-scm.com/downloads)

## 🚀 Guia de Instalação Completo

### Passo 1: Instalar o PostgreSQL

1. Baixe o instalador do PostgreSQL para Windows
2. Execute o instalador e siga as instruções
3. **IMPORTANTE**: Anote a senha que você definir para o usuário `postgres`
4. Mantenha a porta padrão `5432`
5. Aguarde a instalação completar

### Passo 2: Configurar o Banco de Dados

#### Opção A: Usando pgAdmin 4

1. Abra o **pgAdmin 4** (instalado junto com o PostgreSQL)
2. Conecte-se ao servidor PostgreSQL
   - Host: `localhost`
   - Port: `5432`
   - Username: `postgres`
   - Password: (a senha que você definiu)
3. Clique com o botão direito em "Databases" → "Create" → "Database"
4. Digite o nome: `posto_combustivel`
5. Clique em "Save"

#### Opção B: Usando linha de comando (psql)

```bash
# Abra o prompt de comando
# Conecte-se ao PostgreSQL
psql -U postgres

# Digite sua senha quando solicitado
# Execute o comando para criar o banco
CREATE DATABASE posto_combustivel;

# Saia do psql
\q
```

### Passo 3: Configurar o Backend

1. Navegue até a pasta do projeto:
```bash
cd C:\Users\SEU_USUARIO\Documents\pdvcombustivel4\pdvpostobackend
```

2. Abra o arquivo `src\main\resources\application.properties` em um editor de texto

3. Localize a linha:
```properties
spring.datasource.password=sua_senha_aqui
```

4. **Altere** para a senha do seu PostgreSQL:
```properties
spring.datasource.password=SUA_SENHA_AQUI
```

5. Salve o arquivo

### Passo 4: Iniciar o Backend

Abra um terminal (PowerShell ou CMD) e execute:

```bash
# Navegue até a pasta do backend
cd pdvcombustivel4\pdvpostobackend

# Limpe e compile o projeto
mvn clean install

# Inicie o servidor
mvn spring-boot:run
```

**Aguarde** até ver a mensagem:
```
Started PdvpostocombustivelApplication in X.XXX seconds
```

✅ **Backend rodando na porta 8082!**

### Passo 5: Iniciar o Frontend

**IMPORTANTE**: Mantenha o terminal do backend aberto e em execução!

Abra um **NOVO terminal** e execute:

```bash
# Navegue até a pasta do frontend
cd pdvcombustivel4\pdvpostofrontend

# Compile o projeto
mvn clean install

# Inicie a aplicação
mvn exec:java
```

✅ **Interface gráfica será aberta!**

## 🎮 Primeiro Uso

### Criando o Administrador

1. Ao abrir o sistema pela primeira vez, você verá a tela de login
2. Clique no botão **"CRIAR PRIMEIRO ACESSO"**
3. Preencha:
   - **Nome de Usuário**: admin (ou outro de sua preferência)
   - **Senha**: Sua senha segura
   - **Confirmar Senha**: Digite novamente
4. Clique em **"CRIAR"**
5. Aguarde a confirmação de sucesso
6. Volte para a tela de login

### Fazendo Login

1. Digite o usuário e senha que você acabou de criar
2. Clique em **"ENTRAR"**
3. Você será direcionado para o **Dashboard Principal**

## 📱 Funcionalidades do Sistema

### Para Administradores

- ✅ **Gerenciar Pessoas** - Cadastro completo de pessoas (Admin, Frentista, Fornecedor)
- ✅ **Gerenciar Produtos** - Controle de combustíveis e produtos
- ✅ **Gerenciar Estoque** - Monitoramento de estoque
- ✅ **Gerenciar Pre��os** - Definição de preços dos produtos
- ✅ **Gerenciar Custos** - Controle de custos operacionais
- ✅ **Gerenciar Contatos** - Agenda de contatos
- ✅ **Gerenciar Bombas** - Painel de controle das bombas de combustível
- ✅ **Cadastrar Frentistas** - Criar novos usuários frentistas

### Para Frentistas

- ✅ **Gerenciar Bombas** - Acesso exclusivo ao gerenciamento de bombas
- ✅ **Registrar Abastecimentos** - Lançamento de vendas

## 🌐 Documentação da API (Swagger)

Com o backend rodando, acesse no navegador:

```
http://localhost:8082/swagger-ui.html
```

Você terá acesso à documentação interativa da API REST.

## ⚙️ Tecnologias Utilizadas

### Backend
- ☕ Java 17
- 🍃 Spring Boot 3.2.5
- 🐘 PostgreSQL
- 🔄 Hibernate/JPA
- 📦 Maven
- 📚 Swagger/OpenAPI

### Frontend
- ☕ Java Swing
- 🎨 Design Pattern MVC
- 📡 HttpClient Java 11+
- 📦 Maven

## 🎨 Interface do Usuário

O sistema possui uma interface moderna e intuitiva:
- **Paleta de Cores**: Preto, Branco e Vermelho
- **Design Responsivo**: Adapta-se a diferentes resoluções
- **Navegação Intuitiva**: Menu lateral para fácil acesso
- **Cards Informativos**: Visualização clara de dados
- **Efeitos Hover**: Feedback visual nas interações

## 🔧 Solução de Problemas

### ❌ Erro: "FATAL: autenticação do tipo senha falhou"

**Solução**: 
1. Verifique se a senha no `application.properties` está correta
2. Tente conectar ao PostgreSQL pelo pgAdmin com essa senha
3. Se não conseguir, redefina a senha do PostgreSQL

### ❌ Backend não inicia - Porta 8082 em uso

**Solução**:
1. Verifique se já há um processo rodando na porta 8082
2. Mate o processo anterior ou altere a porta no `application.properties`

### ❌ Frontend não conecta ao backend

**Solução**:
1. Verifique se o backend está rodando (terminal ainda ativo)
2. Verifique a URL no console do backend (`http://localhost:8082`)
3. Verifique seu firewall

### ❌ Erro ao compilar (Maven)

**Solução**:
1. Verifique se o Java JDK 17 está instalado: `java -version`
2. Verifique se o Maven está instalado: `mvn -version`
3. Execute `mvn clean install -U` para forçar atualização

## 📊 Estrutura do Projeto

```
pdvcombustivel4/
├── pdvpostobackend/          # Backend Spring Boot
│   ├── src/
│   │   ├── main/
│   │   │   ├── java/
│   │   │   │   └── com/br/pdvpostocombustivel/
│   │   │   │       ├── api/              # Controllers
│   │   │   │       ├── domain/           # Entities e Repositories
│   │   │   │       ├── config/           # Configurações
│   │   │   │       ├── enums/            # Enumerações
│   │   │   │       └── util/             # Utilit��rios
│   │   │   └── resources/
│   │   │       └── application.properties
│   │   └── test/
│   └── pom.xml
│
├── pdvpostofrontend/         # Frontend Java Swing
│   ├── src/
│   │   └── main/
│   │       └── java/
│   │           └── br/com/PdvFrontEnd/
│   │               ├── view/             # Interfaces gráficas
│   │               ├── service/          # Serviços de integração
│   │               ├── model/            # Modelos
│   │               ├── dto/              # Data Transfer Objects
│   │               ├── util/             # Utilitários
│   │               └── MainApp.java      # Classe principal
│   └── pom.xml
│
└── README.md
```

## 🔐 Segurança

- Senhas são armazenadas de forma segura no banco de dados
- Validação de tipos de usuário (ADMIN / FRENTISTA)
- Controle de acesso baseado em roles
- Validações de entrada de dados

## 🎯 Próximos Passos

Após instalar e testar:

1. **Cadastre Produtos**: Adicione os combustíveis e produtos
2. **Configure Preços**: Defina os preços de venda
3. **Registre Fornecedores**: Adicione os fornecedores
4. **Cadastre Frentistas**: Crie acessos para os funcionários
5. **Configure Bombas**: Associe produtos às bombas

## 📞 Suporte

Para dúvidas ou problemas:
- Verifique a seção de **Solução de Problemas**
- Consulte a documentação da API no Swagger
- Entre em contato: **guiscarcela@gmail.com**

## 👨‍💻 Desenvolvedor

**Guilherme Scarcela**  
📧 Email: guiscarcela@gmail.com  
🎓 Desenvolvedor Java Full Stack

## 📄 Licença

Este projeto está sob a licença MIT - veja o arquivo LICENSE para detalhes.

---

## ✨ Desenvolvido com

❤️ **Paixão por tecnologia**  
☕ **Muito café**  
🎯 **Foco em qualidade**

---

**Versão**: 1.0.0  
**Data**: Novembro 2025  
**Status**: ✅ Produção


