# 🎯 PDV Posto de Combustível

Sistema completo de gerenciamento para posto de combustível com Java Spring Boot e Java Swing.

## 🎨 Design Exclusivo

Interface moderna com paleta de cores do grande e soberano tricolor paulista
**Preto (#1E1E1E), Branco (#FAFAFA) e Vermelho (#DC143C)**.

## 🔄 Fluxo do Sistema

### 1️⃣ Primeiro Acesso
- Sistema detecta que não há admin
- Mostra tela para criar o ADMIN
- Admin criado com sucesso

### 2️⃣ Logins Seguintes
- Tela de login normal
- Admin ou Frentista fazem login

### 3️⃣ Admin Logado
- Acessa TODOS os gerenciadores
- Pode cadastrar novos frentistas

### 4️⃣ Frentista Logado
- Acessa APENAS gerenciador de bombas

## ⚡ Início Rápido

### 1. Criar Banco de Dados
```sql
CREATE DATABASE posto_combustivel;
```

### 2. Configurar Backend
Edite `pdvpostobackend/src/main/resources/application.properties`:
```properties
spring.datasource.password=SUA_SENHA_POSTGRES
```

### 3. Iniciar Backend (Terminal 1)
```bash
cd pdvpostobackend
mvn clean install
mvn spring-boot:run
```
✅ Backend na porta **8082**

### 4. Iniciar Frontend (Terminal 2)
```bash
cd pdvpostofrontend
mvn clean install
mvn exec:java
```

### 5. Primeiro Uso
1. Crie o administrador (apenas uma vez)
2. Faça login com as credenciais criadas
3. Use o sistema!

## 📚 Documentação Completa

- **[GUIA_INSTALACAO.md](GUIA_INSTALACAO.md)** - Instalação detalhada
- **[RESUMO_PROJETO.md](RESUMO_PROJETO.md)** - Fluxo completo do sistema

## 🌐 API Documentation

```
http://localhost:8082/swagger-ui.html
```

## ✨ Funcionalidades

**Para ADMINISTRADORES**:
- ✅ Gerenciar Pessoas (Admin/Frentista/Fornecedor)
- ✅ Gerenciar Produtos
- ✅ Gerenciar Estoque
- ✅ Gerenciar Preços
- ✅ Gerenciar Custos
- ✅ Gerenciar Contatos
- ✅ Gerenciar Bombas
- ✅ **Cadastrar Frentistas** (exclusivo do admin)

**Para FRENTISTAS**:
- ✅ Gerenciar Bombas
- ✅ Registrar Abastecimentos

## 🛠️ Tecnologias

**Backend**: Java 17, Spring Boot 3.2.5, PostgreSQL, Swagger  
**Frontend**: Java Swing, HttpClient, Maven

## 🎨 Diferencial Visual

Este projeto possui design **totalmente diferente**:
- Interface moderna em preto, branco e vermelho
- Layout único e exclusivo
- Cards estilizados
- Efeitos hover suaves
- Dashboard com menu lateral

## 👨‍💻 Desenvolvedor

**Guilherme Scarcela**  
📧 Email: guiscarcela@gmail.com

Para dúvidas ou suporte: **guiscarcela@gmail.com**

---
**Desenvolvido por Guilherme Scarcela**




