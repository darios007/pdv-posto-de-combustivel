# 🔧 PDV Posto de Combustível - Backend

API REST desenvolvida em Java Spring Boot para gerenciamento de posto de combustível.

## 🚀 Tecnologias

- Java 17
- Spring Boot 3.2.5
- PostgreSQL
- Hibernate/JPA
- Swagger/OpenAPI
- Maven

## 📦 Instalação

### 1. Configurar Banco de Dados

Crie o banco no PostgreSQL:
```sql
CREATE DATABASE posto_combustivel;
```

### 2. Configurar application.properties

Edite `src/main/resources/application.properties`:
```properties
spring.datasource.password=SUA_SENHA_POSTGRES
```

### 3. Executar

```bash
mvn clean install
mvn spring-boot:run
```

## 📚 Documentação API

Acesse a documentação Swagger:
```
http://localhost:8082/swagger-ui.html
```

## 👨‍💻 Desenvolvedor

**Guilherme Scarcela**  
📧 Email: guiscarcela@gmail.com  
🎓 Desenvolvedor Java Full Stack

---

**Status**: ✅ Funcional | Backend API REST

