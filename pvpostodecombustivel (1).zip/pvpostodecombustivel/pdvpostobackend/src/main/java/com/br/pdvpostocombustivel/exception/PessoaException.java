package com.br.pdvpostocombustivel.exception;

public class PessoaException extends RuntimeException {
    public PessoaException(String message) {
        super(message);
    }
}
