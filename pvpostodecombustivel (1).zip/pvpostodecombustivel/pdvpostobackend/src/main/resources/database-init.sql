-- This script will create the database if it doesn't exist
CREATE DATABASE pdvpostocombustivel WITH OWNER = postgres ENCODING = 'UTF8' LC_COLLATE = 'Portuguese_Brazil.1252' LC_CTYPE = 'Portuguese_Brazil.1252';

